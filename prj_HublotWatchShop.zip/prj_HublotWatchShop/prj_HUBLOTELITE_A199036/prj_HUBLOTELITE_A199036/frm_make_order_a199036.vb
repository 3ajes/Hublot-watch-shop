﻿Imports System.Data.OleDb

Public Class frm_make_order_a199036

    'Update Connection String to your database:
    Private conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Bajes\Desktop\prj_HUBLOTELITE(finalllyyyy)_A199036\prj_HUBLOTELITE_A199036\prj_HUBLOTELITE_A199036\bin\Debug\DB_HUBLOTELITE_A199036.accdb")


    Private Sub frm_make_order_a199036_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: Adapt loading code if needed.  Replace with your actual form loading
        refresh_grid()
    End Sub

    Public Function run_sql_query(mysql As String) As DataTable
        Dim adapter As New OleDbDataAdapter(mysql, conn)
        Dim table As New DataTable()
        adapter.Fill(table)
        Return table
    End Function

    Private Sub refresh_grid()
        'Update Table Name:
        dgvOrder.DataSource = run_sql_query("SELECT * FROM TBL_ORDERS_A199036") ' Changed table name
    End Sub


    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim cmd As New OleDbCommand("INSERT INTO TBL_ORDERS_A199036 (FLD_PRODUCT_ID, FLD_CUSTOMER_ID, FLD_DATE, FLD_STAFF_ID, FLD_TOTAL) VALUES (?, ?, ?, ?, ?)", conn)

        Dim productId As Integer = CInt(InputBox("Enter Product ID (1-40):"))
        If productId < 1 Or productId > 40 Then
            MessageBox.Show("Invalid Product ID. Please enter a number between 1 and 40.")
            Return
        End If

        Dim customerId As Integer = CInt(InputBox("Enter Customer ID (1, 2, or 3):"))
        If customerId < 1 Or customerId > 3 Then
            MessageBox.Show("Invalid Customer ID. Please enter 1, 2, or 3.")
            Return
        End If

        Dim orderDate As Date = CDate(InputBox("Enter Order Date (yyyy-mm-dd):"))

        Dim staffId As Integer = CInt(InputBox("Enter Staff ID (1, 2, or 3):"))
        If staffId < 1 Or staffId > 3 Then
            MessageBox.Show("Invalid Staff ID. Please enter 1, 2, or 3.")
            Return
        End If

        'Update Table Name:
        Dim priceQuery As String = "SELECT FLD_PRICE FROM TBL_PRODUCTS_A199036 WHERE FLD_PRODUCT_ID = " & productId ' Changed table name
        Dim productTable As DataTable = run_sql_query(priceQuery)
        If productTable.Rows.Count = 0 Then
            MessageBox.Show("Product not found.")
            Return
        End If

        Dim total As Decimal = Convert.ToDecimal(productTable.Rows(0)("FLD_PRICE"))

        cmd.Parameters.AddWithValue("@p1", productId)
        cmd.Parameters.AddWithValue("@p2", customerId)
        cmd.Parameters.AddWithValue("@p3", orderDate)
        cmd.Parameters.AddWithValue("@p4", staffId)
        cmd.Parameters.AddWithValue("@p5", total)

        Try
            conn.Open()
            cmd.ExecuteNonQuery()
            MessageBox.Show("Order added successfully.")
            refresh_grid()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try

    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        frm_mainmenu_a199036.Show()
        Me.Close()
    End Sub

    Private Sub btnCancelOrder_Click(sender As Object, e As EventArgs) Handles btnCancelOrder.Click
        ' Get selected customer ID.  You'll need to adapt this based on how your DataGridView is set up
        ' to get the CustomerID from the selected row.  This example assumes a column named "FLD_CUSTOMER_ID" exists in your DataGridView.
        If dgvOrder.SelectedRows.Count = 0 Then
            MessageBox.Show("Please select an order to cancel.")
            Return
        End If
        Dim selectedCustomerID As Integer = CInt(dgvOrder.SelectedRows(0).Cells("FLD_CUSTOMER_ID").Value)

        'Confirmation
        If MessageBox.Show("Are you sure you want to cancel this order for customer ID " & selectedCustomerID & "?", "Confirm Cancellation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.No Then
            Return
        End If

        ' Delete the order for the selected customer
        Dim deleteQuery As String = "DELETE FROM TBL_ORDERS_A199036 WHERE FLD_CUSTOMER_ID = " & selectedCustomerID
        Try
            conn.Open()
            Dim cmd As New OleDbCommand(deleteQuery, conn)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Order canceled successfully.")
            refresh_grid() 'Refresh the DataGridView
        Catch ex As Exception
            MessageBox.Show("Error canceling order: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
End Class
