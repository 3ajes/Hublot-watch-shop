﻿Imports System.Data.OleDb
Public Class frm_orders_a199036
    Private Sub frm_orders_a199036_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Bajes\Desktop\prj_HUBLOTELITE(finalllyyyy)_A199036\prj_HUBLOTELITE_A199036\prj_HUBLOTELITE_A199036\bin\Debug\DB_HUBLOTELITE_A199036.accdb")
        Dim adapter As New OleDbDataAdapter("SELECT * FROM TBL_Orders_A199036", conn)
        Dim table As New DataTable()
        adapter.Fill(table)
        dgvOrders.DataSource = table
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnbmm.Click
        frm_mainmenu_a199036.Show()
        Me.Close()
    End Sub
End Class