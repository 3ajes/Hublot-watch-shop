﻿Imports System.Data.OleDb

Public Class frm_staff_a199036
    Private Sub frm_staff_a199036_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        RefreshGrid()
    End Sub

    Private Sub RefreshGrid()
        Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Bajes\Desktop\prj_HUBLOTELITE(finalllyyyy)_A199036\prj_HUBLOTELITE_A199036\prj_HUBLOTELITE_A199036\bin\Debug\DB_HUBLOTELITE_A199036.accdb")
        Dim adapter As New OleDbDataAdapter("SELECT * FROM TBL_STAFF_A199036", conn)
        Dim table As New DataTable()
        adapter.Fill(table)
        dgvStaff.DataSource = table
    End Sub

    Private Sub btnbmm_Click(sender As Object, e As EventArgs) Handles btnbmm.Click
        frm_mainmenu_a199036.Show()
        Me.Close()
    End Sub

    ' Add Button
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Bajes\Desktop\prj_HUBLOTELITE(finalllyyyy)_A199036\prj_HUBLOTELITE_A199036\prj_HUBLOTELITE_A199036\bin\Debug\DB_HUBLOTELITE_A199036.accdb")
        Dim cmd As New OleDbCommand("INSERT INTO TBL_STAFF_A199036 (FLD_NAME, FLD_POSITION, FLD_PHONE, FLD_EMAIL) VALUES (?, ?, ?, ?)", conn)

        Dim staffName = InputBox("Enter Staff Name:")
        Dim position = InputBox("Enter Position:")
        Dim phone = InputBox("Enter Phone Number:")
        Dim email = InputBox("Enter Email Address:")

        cmd.Parameters.AddWithValue("@p1", staffName)
        cmd.Parameters.AddWithValue("@p2", position)
        cmd.Parameters.AddWithValue("@p3", phone)
        cmd.Parameters.AddWithValue("@p4", email)

        Try
            conn.Open()
            cmd.ExecuteNonQuery()
            MessageBox.Show("Staff added successfully.")
            RefreshGrid()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    ' Edit Button
    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        Dim selectedRow As DataGridViewRow = dgvStaff.CurrentRow
        If selectedRow Is Nothing Then
            MessageBox.Show("Please select a staff member to edit.")
            Return
        End If

        Dim staffId As Integer = selectedRow.Cells("FLD_STAFF_ID").Value
        Dim staffName As String = InputBox("Enter Staff Name:", "Edit Staff", selectedRow.Cells("FLD_NAME").Value.ToString())
        Dim position As String = InputBox("Enter Position:", "Edit Staff", selectedRow.Cells("FLD_POSITION").Value.ToString())
        Dim phone As String = InputBox("Enter Phone Number:", "Edit Staff", selectedRow.Cells("FLD_PHONE").Value.ToString())
        Dim email As String = InputBox("Enter Email Address:", "Edit Staff", selectedRow.Cells("FLD_EMAIL").Value.ToString())

        Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Bajes\Desktop\prj_HUBLOTELITE(finalllyyyy)_A199036\prj_HUBLOTELITE_A199036\prj_HUBLOTELITE_A199036\bin\Debug\DB_HUBLOTELITE_A199036.accdb")
        Dim cmd As New OleDbCommand("UPDATE TBL_STAFF_A199036 SET FLD_NAME = ?, FLD_POSITION = ?, FLD_PHONE = ?, FLD_EMAIL = ? WHERE FLD_STAFF_ID = ?", conn)

        cmd.Parameters.AddWithValue("@p1", staffName)
        cmd.Parameters.AddWithValue("@p2", position)
        cmd.Parameters.AddWithValue("@p3", phone)
        cmd.Parameters.AddWithValue("@p4", email)
        cmd.Parameters.AddWithValue("@p5", staffId)

        Try
            conn.Open()
            cmd.ExecuteNonQuery()
            MessageBox.Show("Staff details updated successfully.")
            RefreshGrid()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    ' Delete Button
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim selectedRow As DataGridViewRow = dgvStaff.CurrentRow
        If selectedRow Is Nothing Then
            MessageBox.Show("Please select a staff member to delete.")
            Return
        End If

        Dim staffId As Integer = selectedRow.Cells("FLD_STAFF_ID").Value

        If MessageBox.Show("Are you sure you want to delete this staff member?", "Confirm Delete", MessageBoxButtons.YesNo) = DialogResult.Yes Then
            Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Bajes\Desktop\prj_HUBLOTELITE(finalllyyyy)_A199036\prj_HUBLOTELITE_A199036\prj_HUBLOTELITE_A199036\bin\Debug\DB_HUBLOTELITE_A199036.accdb")
            Dim cmd As New OleDbCommand("DELETE FROM TBL_STAFF_A199036 WHERE FLD_STAFF_ID = ?", conn)
            cmd.Parameters.AddWithValue("@p1", staffId)

            Try
                conn.Open()
                cmd.ExecuteNonQuery()
                MessageBox.Show("Staff deleted successfully.")
                RefreshGrid()
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            Finally
                conn.Close()
            End Try
        End If
    End Sub
End Class
