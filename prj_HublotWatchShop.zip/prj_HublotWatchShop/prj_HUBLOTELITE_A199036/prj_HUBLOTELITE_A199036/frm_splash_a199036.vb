﻿Public Class frm_splash_a199036

    Private Sub frm_splash_a199036_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        splashT.Start()
    End Sub

    Private Sub splashT_Tick(sender As Object, e As EventArgs) Handles splashT.Tick
        splashT.Stop()
        Dim mainMenu As New frm_mainmenu_a199036()
        mainMenu.Show()
        Me.Hide()
    End Sub
End Class
