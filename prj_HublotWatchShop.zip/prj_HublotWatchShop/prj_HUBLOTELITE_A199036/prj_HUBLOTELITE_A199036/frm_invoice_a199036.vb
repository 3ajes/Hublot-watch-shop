﻿Imports System.Data.OleDb

Public Class frm_invoice_a199036

    'Make sure you have a DataGridView named "dgvOrders" on your form.

    Private conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Bajes\Desktop\prj_HUBLOTELITE(finalllyyyy)_A199036\prj_HUBLOTELITE_A199036\prj_HUBLOTELITE_A199036\bin\Debug\DB_HUBLOTELITE_A199036.accdb")

    Private Sub frm_invoice_a199036_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dgvOrders.Columns.Clear() ' Clear existing columns

        ' Add columns to the DataGridView (adjust names as needed)
        AddDataGridViewTextBoxColumn(dgvOrders, "OrderID", "Order ID", "FLD_ORDER_ID")
        AddDataGridViewTextBoxColumn(dgvOrders, "CustomerID", "Customer ID", "FLD_CUSTOMER_ID")
        AddDataGridViewTextBoxColumn(dgvOrders, "OrderDate", "Order Date", "FLD_DATE")
        AddDataGridViewTextBoxColumn(dgvOrders, "StaffID", "Staff ID", "FLD_STAFF_ID")
        AddDataGridViewTextBoxColumn(dgvOrders, "Total", "Total", "FLD_TOTAL")

        LoadOrders()
    End Sub


    Private Sub AddDataGridViewTextBoxColumn(dgv As DataGridView, name As String, headerText As String, dataPropertyName As String)
        Dim col As New DataGridViewTextBoxColumn()
        col.Name = name
        col.HeaderText = headerText
        col.DataPropertyName = dataPropertyName
        col.ReadOnly = True
        dgv.Columns.Add(col)
    End Sub


    Private Sub LoadOrders()
        Dim query As String = "SELECT FLD_ORDER_ID, FLD_CUSTOMER_ID, FLD_DATE, FLD_STAFF_ID, FLD_TOTAL FROM tbl_orders_a199036" ' Adjust column names to match your table

        Using adapter As New OleDbDataAdapter(query, conn)
            Dim orderTable As New DataTable()
            adapter.Fill(orderTable)
            dgvOrders.DataSource = orderTable
        End Using
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        frm_mainmenu_a199036.Show()
        Me.Close()
    End Sub

End Class

