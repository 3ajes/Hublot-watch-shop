﻿Public Class frm_mainmenu_a199036
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub btnProducts_Click(sender As Object, e As EventArgs) Handles btnProducts.Click
        Dim frm As New frm_products_a199036
        frm.Show()

    End Sub

    Private Sub frm_mainmenu_a199036_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnCustomers_Click(sender As Object, e As EventArgs) Handles btnCustomers.Click
        Dim frm As New frm_customers_a199036
        frm.Show()
    End Sub

    Private Sub btnOrders_Click(sender As Object, e As EventArgs) Handles btnOrders.Click
        Dim frm As New frm_orders_a199036
        frm.Show()
    End Sub

    Private Sub btnStaff_Click(sender As Object, e As EventArgs) Handles btnStaff.Click
        Dim frm As New frm_staff_a199036
        frm.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim frm As New frm_make_order_a199036
        frm.Show()

    End Sub

    Private Sub btnViewOrder_Click(sender As Object, e As EventArgs) Handles btnViewOrder.Click
        Dim frm As New frm_invoice_a199036
        frm.Show()

    End Sub
End Class
