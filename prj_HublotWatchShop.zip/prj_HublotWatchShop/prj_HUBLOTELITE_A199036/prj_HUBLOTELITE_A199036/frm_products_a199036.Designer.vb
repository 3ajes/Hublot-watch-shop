﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_products_a199036
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnbmm = New System.Windows.Forms.Button()
        Me.dgvProducts = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnSelectImage = New System.Windows.Forms.Button()
        Me.picProduct = New System.Windows.Forms.PictureBox()
        Me.txtImagePath = New System.Windows.Forms.TextBox()
        CType(Me.dgvProducts, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picProduct, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnbmm
        '
        Me.btnbmm.Location = New System.Drawing.Point(12, 21)
        Me.btnbmm.Name = "btnbmm"
        Me.btnbmm.Size = New System.Drawing.Size(152, 23)
        Me.btnbmm.TabIndex = 0
        Me.btnbmm.Text = "Back to Main Menu "
        Me.btnbmm.UseVisualStyleBackColor = True
        '
        'dgvProducts
        '
        Me.dgvProducts.BackgroundColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgvProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvProducts.Location = New System.Drawing.Point(12, 243)
        Me.dgvProducts.Name = "dgvProducts"
        Me.dgvProducts.RowHeadersWidth = 51
        Me.dgvProducts.RowTemplate.Height = 24
        Me.dgvProducts.Size = New System.Drawing.Size(865, 382)
        Me.dgvProducts.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Showcard Gothic", 28.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(235, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(375, 60)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "HUBLOT ELITE "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 19.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(338, 200)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(190, 37)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Our Products"
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(12, 160)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(151, 23)
        Me.btnAdd.TabIndex = 4
        Me.btnAdd.Text = "Add New Product"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'btnEdit
        '
        Me.btnEdit.Location = New System.Drawing.Point(12, 189)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(164, 23)
        Me.btnEdit.TabIndex = 5
        Me.btnEdit.Text = "Edit Existing Product"
        Me.btnEdit.UseVisualStyleBackColor = True
        '
        'btnDelete
        '
        Me.btnDelete.Location = New System.Drawing.Point(12, 214)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(177, 23)
        Me.btnDelete.TabIndex = 6
        Me.btnDelete.Text = "Delete Selected Product"
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnSelectImage
        '
        Me.btnSelectImage.Location = New System.Drawing.Point(720, 50)
        Me.btnSelectImage.Name = "btnSelectImage"
        Me.btnSelectImage.Size = New System.Drawing.Size(108, 23)
        Me.btnSelectImage.TabIndex = 7
        Me.btnSelectImage.Text = "Select Image"
        Me.btnSelectImage.UseVisualStyleBackColor = True
        '
        'picProduct
        '
        Me.picProduct.Location = New System.Drawing.Point(720, 107)
        Me.picProduct.Name = "picProduct"
        Me.picProduct.Size = New System.Drawing.Size(157, 123)
        Me.picProduct.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picProduct.TabIndex = 8
        Me.picProduct.TabStop = False
        '
        'txtImagePath
        '
        Me.txtImagePath.Location = New System.Drawing.Point(720, 79)
        Me.txtImagePath.Name = "txtImagePath"
        Me.txtImagePath.Size = New System.Drawing.Size(108, 22)
        Me.txtImagePath.TabIndex = 9
        '
        'frm_products_a199036
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.ClientSize = New System.Drawing.Size(889, 637)
        Me.Controls.Add(Me.txtImagePath)
        Me.Controls.Add(Me.picProduct)
        Me.Controls.Add(Me.btnSelectImage)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnEdit)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.dgvProducts)
        Me.Controls.Add(Me.btnbmm)
        Me.Name = "frm_products_a199036"
        Me.Text = "Products"
        CType(Me.dgvProducts, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picProduct, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnbmm As Button
    Friend WithEvents dgvProducts As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnEdit As Button
    Friend WithEvents btnDelete As Button
    Friend WithEvents btnSelectImage As Button
    Friend WithEvents picProduct As PictureBox
    Friend WithEvents txtImagePath As TextBox
End Class
