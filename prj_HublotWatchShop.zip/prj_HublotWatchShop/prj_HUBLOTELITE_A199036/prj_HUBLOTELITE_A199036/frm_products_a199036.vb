﻿Imports System.Data.OleDb
Imports System.IO
Public Class frm_products_a199036
    Dim connectionString As String = ("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Bajes\Desktop\prj_HUBLOTELITE(finalllyyyy)_A199036\prj_HUBLOTELITE_A199036\prj_HUBLOTELITE_A199036\bin\Debug\DB_HUBLOTELITE_A199036.accdb")

    Private Sub frm_products_a199036_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim adapter As New OleDbDataAdapter("SELECT * FROM TBL_PRODUCTS_A199036", connectionString)
        Dim table As New DataTable()
        adapter.Fill(table)
        dgvProducts.DataSource = table
    End Sub


    Private Sub dgvProducts_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvProducts.CellClick
        If dgvProducts.CurrentRow IsNot Nothing Then
            Try
                Dim productId As Integer = dgvProducts.CurrentRow.Cells("FLD_PRODUCT_ID").Value
                Dim imagePath As String = Path.Combine(Application.StartupPath, "pictures", productId.ToString() & ".png")

                If File.Exists(imagePath) Then
                    Using fs As New FileStream(imagePath, FileMode.Open, FileAccess.Read)
                        picProduct.Image = Image.FromStream(fs)
                    End Using
                Else
                    picProduct.Image = Nothing
                End If
            Catch ex As Exception
                MessageBox.Show("Unable to display product image: " & ex.Message)
                picProduct.Image = Nothing
            End Try
        End If
    End Sub


    Private Sub RefreshGrid()
        Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Bajes\Desktop\prj_HUBLOTELITE(finalllyyyy)_A199036\prj_HUBLOTELITE_A199036\prj_HUBLOTELITE_A199036\bin\Debug\DB_HUBLOTELITE_A199036.accdb")
        Dim adapter As New OleDbDataAdapter("SELECT * FROM TBL_PRODUCTS_A199036", conn)
        Dim table As New DataTable()
        adapter.Fill(table)
        dgvProducts.DataSource = table
    End Sub
    Private Sub btnSelectImage_Click(sender As Object, e As EventArgs) Handles btnSelectImage.Click
        Dim ofd As New OpenFileDialog()

        ofd.Filter = "Image Files|.jpg;.jpeg;.png;.bmp"

        If ofd.ShowDialog() = DialogResult.OK Then
            Try
                picProduct.Image = Image.FromFile(ofd.FileName)

                txtImagePath.Text = ofd.FileName
            Catch ex As Exception
                MessageBox.Show("Error loading image: " & ex.Message)
            End Try
        End If
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Bajes\Desktop\prj_HUBLOTELITE(finalllyyyy)_A199036\prj_HUBLOTELITE_A199036\prj_HUBLOTELITE_A199036\bin\Debug\DB_HUBLOTELITE_A199036.accdb")
        Dim cmd As New OleDbCommand("INSERT INTO TBL_PRODUCTS_A199036 (FLD_PRODUCT_NAME, FLD_PRICE, FLD_BRAND, FLD_CATEGORY, FLD_DESCRIPTON, FLD_QUANTITY) VALUES (?, ?, ?, ?, ?, ?)", conn)



        Dim productName = InputBox("Enter Product Name:")
        Dim productPrice = InputBox("Enter Product Price:")
        Dim brandName = InputBox("Enter Brand Name:")
        Dim category = InputBox("Enter Category:")
        Dim description = InputBox("Enter Description:")
        Dim quantity = InputBox("Enter Quantity:")

        cmd.Parameters.AddWithValue("@p1", productName)
        cmd.Parameters.AddWithValue("@p2", productPrice)
        cmd.Parameters.AddWithValue("@p3", brandName)
        cmd.Parameters.AddWithValue("@p4", category)
        cmd.Parameters.AddWithValue("@p5", description)
        cmd.Parameters.AddWithValue("@p6", quantity)

        Try
            conn.Open()
            cmd.ExecuteNonQuery()
            MessageBox.Show("Product added successfully.")
            RefreshGrid()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim selectedRow As DataGridViewRow = dgvProducts.CurrentRow
        If selectedRow Is Nothing Then
            MessageBox.Show("Please select a product to delete.")
            Return
        End If

        Dim productId = selectedRow.Cells("FLD_PRODUCT_ID").Value

        If MessageBox.Show("Are you sure you want to delete this product?", "Confirm Delete", MessageBoxButtons.YesNo) = DialogResult.Yes Then
            Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Bajes\Desktop\prj_HUBLOTELITE(finalllyyyy)_A199036\prj_HUBLOTELITE_A199036\prj_HUBLOTELITE_A199036\bin\Debug\DB_HUBLOTELITE_A199036.accdb")
            Dim cmd As New OleDbCommand("DELETE FROM TBL_PRODUCTS_A199036 WHERE FLD_PRODUCT_ID = ?", conn)
            cmd.Parameters.AddWithValue("@p1", productId)

            Try
                conn.Open()
                cmd.ExecuteNonQuery()
                MessageBox.Show("Product deleted successfully.")
                RefreshGrid()

            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            Finally
                conn.Close()
            End Try
        End If
    End Sub

    Private Sub btnbmm_Click(sender As Object, e As EventArgs) Handles btnbmm.Click
        frm_mainmenu_a199036.Show()
        Me.Close()
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        Dim selectedRow As DataGridViewRow = dgvProducts.CurrentRow
        If selectedRow Is Nothing Then
            MessageBox.Show("Please select a product to edit.")
            Return
        End If

        Dim productId As Integer = selectedRow.Cells("FLD_PRODUCT_ID").Value

        Dim productName As String = InputBox("Enter Product Name:", "Edit Product", selectedRow.Cells("FLD_PRODUCT_NAME").Value.ToString())
        Dim productPrice As String = InputBox("Enter Product Price:", "Edit Product", selectedRow.Cells("FLD_PRICE").Value.ToString())
        Dim brandName As String = InputBox("Enter Brand Name:", "Edit Product", selectedRow.Cells("FLD_BRAND").Value.ToString())
        Dim category As String = InputBox("Enter Category:", "Edit Product", selectedRow.Cells("FLD_CATEGORY").Value.ToString())
        Dim description As String = InputBox("Enter Description:", "Edit Product", selectedRow.Cells("FLD_DESCRIPTON").Value.ToString())
        Dim quantity As String = InputBox("Enter Quantity:", "Edit Product", selectedRow.Cells("FLD_QUANTITY").Value.ToString())

        Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Bajes\Desktop\prj_HUBLOTELITE(finalllyyyy)_A199036\prj_HUBLOTELITE_A199036\prj_HUBLOTELITE_A199036\bin\Debug\DB_HUBLOTELITE_A199036.accdb")
        Dim cmd As New OleDbCommand("UPDATE TBL_PRODUCTS_A199036 SET FLD_PRODUCT_NAME = ?, FLD_PRICE = ?, FLD_BRAND = ?, FLD_CATEGORY = ?, FLD_DESCRIPTON = ?, FLD_QUANTITY = ? WHERE FLD_PRODUCT_ID = ?", conn)

        cmd.Parameters.AddWithValue("@p1", productName)
        cmd.Parameters.AddWithValue("@p2", productPrice)
        cmd.Parameters.AddWithValue("@p3", brandName)
        cmd.Parameters.AddWithValue("@p4", category)
        cmd.Parameters.AddWithValue("@p5", description)
        cmd.Parameters.AddWithValue("@p6", quantity)
        cmd.Parameters.AddWithValue("@p7", productId)

        Try
            conn.Open()
            cmd.ExecuteNonQuery()
            MessageBox.Show("Product updated successfully.")
            RefreshGrid() ' Refresh the DataGridView to reflect the updated data
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

End Class