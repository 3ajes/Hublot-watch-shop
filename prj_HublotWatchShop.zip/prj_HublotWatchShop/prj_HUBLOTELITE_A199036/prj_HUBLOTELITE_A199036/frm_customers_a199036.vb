﻿Imports System.Data.OleDb
Public Class frm_customers_a199036
    Private Sub frm_customers_a199036_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Bajes\Desktop\prj_HUBLOTELITE(finalllyyyy)_A199036\prj_HUBLOTELITE_A199036\prj_HUBLOTELITE_A199036\bin\Debug\DB_HUBLOTELITE_A199036.accdb")
        Dim adapter As New OleDbDataAdapter("SELECT * FROM TBL_Customer_A199036", conn)
        Dim table As New DataTable()
        adapter.Fill(table)
        dgvCustomers.DataSource = table
    End Sub

    Private Sub RefreshGrid()
        Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Bajes\Desktop\prj_HUBLOTELITE(finalllyyyy)_A199036\prj_HUBLOTELITE_A199036\prj_HUBLOTELITE_A199036\bin\Debug\DB_HUBLOTELITE_A199036.accdb")
        Dim adapter As New OleDbDataAdapter("SELECT * FROM TBL_Customer_A199036", conn)
        Dim table As New DataTable()
        adapter.Fill(table)
        dgvCustomers.DataSource = table
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnbmm.Click
        frm_mainmenu_a199036.Show()
        Me.Close()
    End Sub

    ' Add Button
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Bajes\Desktop\prj_HUBLOTELITE(finalllyyyy)_A199036\prj_HUBLOTELITE_A199036\prj_HUBLOTELITE_A199036\bin\Debug\DB_HUBLOTELITE_A199036.accdb")
        Dim cmd As New OleDbCommand("INSERT INTO TBL_Customer_A199036 (FLD_NAME, FLD_PHONE, FLD_EMAIL, FLD_ADDRESS) VALUES (?, ?, ?, ?)", conn)

        Dim customerName = InputBox("Enter Name:")
        Dim phone = InputBox("Enter Phone Number:")
        Dim email = InputBox("Enter Email:")
        Dim address = InputBox("Enter Address:")

        cmd.Parameters.AddWithValue("@p1", customerName)
        cmd.Parameters.AddWithValue("@p2", phone)
        cmd.Parameters.AddWithValue("@p3", email)
        cmd.Parameters.AddWithValue("@p4", address)

        Try
            conn.Open()
            cmd.ExecuteNonQuery()
            MessageBox.Show("Customer added successfully.")
            RefreshGrid()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    ' Edit Button
    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        Dim selectedRow As DataGridViewRow = dgvCustomers.CurrentRow
        If selectedRow Is Nothing Then
            MessageBox.Show("Please select a customer to edit.")
            Return
        End If

        Dim customerId As Integer = selectedRow.Cells("FLD_CUSTOMER_ID").Value
        Dim customerName As String = InputBox("Enter Name:", "Edit Customer", selectedRow.Cells("FLD_NAME").Value.ToString())
        Dim phone As String = InputBox("Enter Phone Number:", "Edit Customer", selectedRow.Cells("FLD_PHONE").Value.ToString())
        Dim email As String = InputBox("Enter Email:", "Edit Customer", selectedRow.Cells("FLD_EMAIL").Value.ToString())
        Dim address As String = InputBox("Enter Address:", "Edit Customer", selectedRow.Cells("FLD_ADDRESS").Value.ToString())

        Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Bajes\Desktop\prj_HUBLOTELITE(finalllyyyy)_A199036\prj_HUBLOTELITE_A199036\prj_HUBLOTELITE_A199036\bin\Debug\DB_HUBLOTELITE_A199036.accdb")
        Dim cmd As New OleDbCommand("UPDATE TBL_Customer_A199036 SET FLD_NAME = ?, FLD_PHONE = ?, FLD_EMAIL = ?, FLD_ADDRESS = ? WHERE FLD_CUSTOMER_ID = ?", conn)

        cmd.Parameters.AddWithValue("@p1", customerName)
        cmd.Parameters.AddWithValue("@p2", phone)
        cmd.Parameters.AddWithValue("@p3", email)
        cmd.Parameters.AddWithValue("@p4", address)
        cmd.Parameters.AddWithValue("@p5", customerId)

        Try
            conn.Open()
            cmd.ExecuteNonQuery()
            MessageBox.Show("Customer updated successfully.")
            RefreshGrid()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    ' Delete Button
    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Dim selectedRow As DataGridViewRow = dgvCustomers.CurrentRow
        If selectedRow Is Nothing Then
            MessageBox.Show("Please select a customer to delete.")
            Return
        End If

        Dim customerId As Integer = selectedRow.Cells("FLD_CUSTOMER_ID").Value

        If MessageBox.Show("Are you sure you want to delete this customer?", "Confirm Delete", MessageBoxButtons.YesNo) = DialogResult.Yes Then
            Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Bajes\Desktop\prj_HUBLOTELITE(finalllyyyy)_A199036\prj_HUBLOTELITE_A199036\prj_HUBLOTELITE_A199036\bin\Debug\DB_HUBLOTELITE_A199036.accdb")
            Dim cmd As New OleDbCommand("DELETE FROM TBL_Customer_A199036 WHERE FLD_CUSTOMER_ID = ?", conn)
            cmd.Parameters.AddWithValue("@p1", customerId)

            Try
                conn.Open()
                cmd.ExecuteNonQuery()
                MessageBox.Show("Customer deleted successfully.")
                RefreshGrid()
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            Finally
                conn.Close()
            End Try
        End If
    End Sub
End Class
